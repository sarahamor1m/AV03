from config.db import *


def inserir_categoria(nome):
    conn = criar_conexao()
    try:
        cursor = conn.cursor()
        query = "INSERT INTO checklist.tasks.categorias (nome) VALUES (%s) RETURNING id;"
        cursor.execute(query, (nome,))
        categoria_id = cursor.fetchone()[0]
        conn.commit()
        print(f"Categoria '{nome}' inserida com sucesso!")
        return categoria_id
    except Exception as e:
        print(f"Erro ao inserir categoria: {e}")
    finally:
        cursor.close()
        conn.close()


def listar_categorias():
    conn = criar_conexao()
    try:
        cursor = conn.cursor()
        query = "SELECT id, nome FROM checklist.tasks.categorias;"
        cursor.execute(query)
        categorias = cursor.fetchall()
        return categorias
    except Exception as e:
        print(f"Erro ao listar categorias: {e}")
        return []
    finally:
        cursor.close()
        conn.close()
