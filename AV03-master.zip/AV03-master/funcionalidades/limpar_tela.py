from os import system, name


def limpar_tela():
    if name == 'nt':
        _ = system('cls')
    else:
        _ = system('clear')
