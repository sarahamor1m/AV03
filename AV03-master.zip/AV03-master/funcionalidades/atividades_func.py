from persistencia_de_dados.atividades import *
from funcionalidades.validar_data import validar_data
from time import sleep
from funcionalidades.categorias import *


def cadastrar_atividade(id_usuario):
    titulo = input("Título: ").strip()
    while not titulo:
        print("Título não pode ser vazio.")
        titulo = input("Título: ").strip()

    descricao = input("Descrição [Pressione Enter para deixar em branco]: ").strip()

    data_conclusao = input("Data de conclusão [aaaa-mm-dd]: ")
    while not validar_data(data_conclusao):
        print("Erro ao cadastrar atividade: digite a data no formato aaaa-mm-dd!")
        data_conclusao = input("Data de conclusão [aaaa-mm-dd]: ")

    categorias = listar_categorias()
    if not categorias:
        print("Não há categorias disponíveis. Por favor, cadastre uma categoria primeiro.")
        return

    print("\nCategorias disponíveis:")
    for indice, categoria in enumerate(categorias, start=1):
        print(f"{indice}. {categoria[1]}")

    escolha_categoria = int(input("\nEscolha uma categoria pelo número: "))
    if 1 <= escolha_categoria <= len(categorias):
        id_categoria = categorias[escolha_categoria - 1][0]
        inserir_atividade(titulo=titulo, descricao=descricao, data_conclusao=data_conclusao, id_usuario=id_usuario, id_categoria=id_categoria)
    else:
        print("Categoria inválida.")


def visualizar_atividades(id_usuario):
    atividades = listar_atividades(id_usuario)
    for indice, atividade in enumerate(atividades, start=1):
        id_atividade, titulo, descricao, data_criacao, data_conclusao, concluida, prioridade, id_categoria = atividade

        conn = criar_conexao()
        cursor = conn.cursor()
        cursor.execute("SELECT nome FROM checklist.tasks.categorias WHERE id = %s", [id_categoria])
        categoria = cursor.fetchone()
        conn.close()

        if categoria:
            categoria_nome = categoria[0]
        else:
            categoria_nome = "Sem categoria"

        if concluida:
            status = '✓'
        else:
            status = ' '
        print(f"{indice}. {titulo} [{status}]")
        print(f"ID: {id_atividade}")
        print(f"Descrição: {descricao}")
        print(f"Categoria: {categoria_nome}")
        print(f"Data de conclusão: {data_conclusao.strftime('%Y-%m-%d')}")
        print(f"🕐 {data_criacao.strftime('%Y-%m-%d %H:%M:%S')}")
        print("-" * 20)


def concluir_atividade(id_usuario):
    visualizar_atividades(id_usuario=id_usuario)
    # try catch
    id_atividade = int(input("Digite o ID da atividade que deseja marcar como concluída: "))
    if marcar_concluida(id_usuario=id_usuario, id_atividades=id_atividade, concluida=True):
        print("Atividade marcada como concluída!")


def deletar_atividade(id_usuario):
    visualizar_atividades(id_usuario=id_usuario)

    id_atividade = int(input("Digite o ID da atividade que deseja deletar: "))

    if deletar(id_usuario=id_usuario, id_atividades=id_atividade):
        return f"Atividade deletada"


def atualizar_atividade(id_usuario):
    visualizar_atividades(id_usuario=id_usuario)

    id_atividade = int(input("Digite o ID da atividade que deseja atualizar: "))

    # Buscar a atividade diretamente
    atividades = listar_atividades(id_usuario)
    atividade_atual = None

    for atividade in atividades:
        if atividade[0] == id_atividade:
            atividade_atual = atividade
            break

    if atividade_atual:
        id_atividade, titulo, descricao, data_criacao, data_conclusao, concluida, prioridade = atividade_atual

        # Perguntar os novos dados ao usuário
        novo_titulo = input(f"Novo título (deixe em branco para manter '{titulo}'): ")
        if not novo_titulo:
            novo_titulo = titulo

        nova_descricao = input(f"Nova descrição (deixe em branco para manter '{descricao}'): ")
        if not nova_descricao:
            nova_descricao = descricao

        # Confirmar antes de atualizar
        confirmar = input(f"Confirmar? (s/n): ").lower()
        if confirmar == 's':
            atualizar(id_usuario=id_usuario, id_atividades=id_atividade, titulo=novo_titulo, descricao=nova_descricao)
            print("Atividade atualizada com sucesso!")
        else:
            print("Atualização cancelada.")
    else:
        print("Atividade não encontrada.")
