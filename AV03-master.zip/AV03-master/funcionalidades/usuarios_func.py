from persistencia_de_dados.usuarios import *
from funcionalidades.validar_email import validar_email
from funcionalidades.limpar_tela import limpar_tela
from persistencia_de_dados.seguranca import criptografar


def cadastrar_usuario():
    nome = input("Nome: ").lower()
    email = input("Email: ").lower()
    senha = input("Senha: ")

    if validar_email(email=email):
        # Criptografar a senha antes de salvar no banco
        senha_hash = criptografar(senha).decode('utf-8')
        inserir_usuario(nome=nome, email=email, senha=senha_hash)
    else:
        print("Email inválido")
        opc = input("Deseja tentar novamente? [s/n]: ").lower()
        if opc == 's':
            limpar_tela()
            print("Tente novamente")
            cadastrar_usuario()
        else:
            return


def login():
    email = input("Email: ").lower()
    senha = input("Senha: ")
    limpar_tela()

    usuario_autenticado = autenticar_usuario(email=email, senha=senha)

    if usuario_autenticado:
        id_usuario, nome_usuario = usuario_autenticado
        nome = nome_usuario.title()

        print(f"Bem-vindo, {nome}!")
        return id_usuario
    else:
        print("Usuário ou senha inválidos!")
        return None
