from psycopg2 import IntegrityError
from config.db import criar_conexao
from time import sleep
from persistencia_de_dados.seguranca import *


def inserir_usuario(nome, email, senha):
    conn = criar_conexao()
    try:
        cursor = conn.cursor()
        query = "INSERT INTO checklist.user.usuarios (nome, email, senha) VALUES (%s, %s, %s);"
        cursor.execute(query, (nome, email, senha))
        conn.commit()
        print("Usuário inserido com sucesso!")
    except IntegrityError as e:
        print(f"Erro: email já cadastrado!\n")
        sleep(2)
    finally:
        cursor.close()
        conn.close()


def autenticar_usuario(email, senha):
    conn = criar_conexao()
    cursor = conn.cursor()
    try:
        # Buscar o hash da senha no banco
        sql = "SELECT id, nome, senha FROM checklist.user.usuarios WHERE email = %s"
        cursor.execute(sql, (email,))
        usuario = cursor.fetchone()

        if usuario:
            id_usuario, nome_usuario, senha_hash = usuario

            # Comparar a senha informada com o hash armazenado
            if checar_password(senha, senha_hash.encode('utf-8')):
                return id_usuario, nome_usuario
        return None
    finally:
        cursor.close()
        conn.close()


def corrigir_senhas():
    conn = criar_conexao()
    cursor = conn.cursor()
    try:
        # Buscar todas as senhas no banco
        cursor.execute("SELECT id, senha FROM checklist.user.usuarios;")
        usuarios = cursor.fetchall()

        for usuario in usuarios:
            id_usuario, senha_atual = usuario

            # Criptografar apenas senhas que não estão no formato hash
            if not senha_atual.startswith("$2b$"):
                senha_hash = criptografar(senha_atual).decode('utf-8')
                cursor.execute(
                    "UPDATE checklist.user.usuarios SET senha = %s WHERE id = %s",
                    (senha_hash, id_usuario),
                )

        conn.commit()
        # print("Senhas corrigidas com sucesso!")
    finally:
        cursor.close()
        conn.close()


corrigir_senhas()

