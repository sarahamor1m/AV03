import bcrypt


def criptografar(senha):
    password_bytes = senha.encode('utf-8')
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password_bytes, salt)
    return hashed


def checar_password(senha, hashed):
    password_bytes = senha.encode('utf-8')
    return bcrypt.checkpw(password_bytes, hashed)


senha = "minha_senha"
hash_senha = criptografar(senha)
# print("Hash:", hash_senha)

if not checar_password("minha_senha", hash_senha):
    print("Senha inválida!")