from config.db import criar_conexao


def inserir_atividade(titulo, descricao, data_conclusao, id_usuario, id_categoria):
    conn = criar_conexao()
    try:
        cursor = conn.cursor()
        query = "INSERT INTO checklist.tasks.atividades (titulo, descricao, data_conclusao, id_usuario, id_categoria) VALUES (%s, %s, %s, %s, %s);"
        cursor.execute(query, [titulo, descricao, data_conclusao, id_usuario, id_categoria])
        conn.commit()
        print(f"Tarefa '{titulo}' inserida com sucesso!")
    except Exception as e:
        print(f"Erro ao inserir tarefa: {e}")
    finally:
        cursor.close()
        conn.close()


def listar_atividades(id_usuario):
    conn = criar_conexao()
    cursor = conn.cursor()
    sql = 'SELECT * FROM checklist.tasks.atividades WHERE id_usuario = %s'
    cursor.execute(sql, [id_usuario])
    atividades = cursor.fetchall()
    return atividades


def marcar_concluida(id_usuario, id_atividades, concluida):
    conn = criar_conexao()
    cursor = conn.cursor()
    sql = 'UPDATE checklist.tasks.atividades SET concluida = %s WHERE id_usuario = %s AND id_atividades = %s'
    cursor.execute(sql, [concluida, id_usuario, id_atividades])
    conn.commit()


def deletar(id_usuario, id_atividades):
    conn = criar_conexao()
    cursor = conn.cursor()
    sql = 'DELETE FROM checklist.tasks.atividades WHERE id_usuario = %s AND id_atividades = %s'
    cursor.execute(sql, [id_usuario, id_atividades])
    conn.commit()
    # return cursor.rowcount


def atualizar(id_usuario, id_atividades, titulo, descricao):
    conn = criar_conexao()
    cursor = conn.cursor()
    sql = 'UPDATE checklist.tasks.atividades SET titulo = %s, descricao = %s WHERE id_usuario = %s AND id_atividades = %s'
    cursor.execute(sql, [titulo, descricao, id_usuario, id_atividades])
    conn.commit()
