from funcionalidades.usuarios_func import *
from funcionalidades.limpar_tela import limpar_tela
from telas.menu_atividades import *

while True:
    print("Menu")
    print("1 - CADASTRAR USUÁRIO")
    print("2 - LOGIN")
    print("3 - SAIR")
    opc = input("Digite a opção desejada: ")

    if opc == "1":
        cadastrar_usuario()
        limpar_tela()

    elif opc == "2":
        id_logado = login()

        if id_logado:
            menu_atividades(user_id=id_logado)

    elif opc == "3":
        break

    else:
        limpar_tela()
