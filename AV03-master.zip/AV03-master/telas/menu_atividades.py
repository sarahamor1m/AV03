from funcionalidades.atividades_func import *
from funcionalidades.limpar_tela import limpar_tela
from funcionalidades.categorias import *


def menu_atividades(user_id):
    while True:
        print("1 - Cadastrar atividade")
        print("2 - Visualizar atividades")
        print("3 - Concluir atividade")
        print("4 - Deletar atividade")
        print("5 - Atualizar atividade")
        print("6 - Adicionar categoria")
        print("7 - Listar categorias")
        print(" - Sair")
        opc = input("Digite a opção desejada: ")

        if opc == "1":
            limpar_tela()
            cadastrar_atividade(id_usuario=user_id)
            limpar_tela()

        elif opc == "2":
            limpar_tela()
            visualizar_atividades(id_usuario=user_id)

        elif opc == "3":
            limpar_tela()
            concluir_atividade(id_usuario=user_id)
            limpar_tela()

        elif opc == "4":
            limpar_tela()
            deletar_atividade(id_usuario=user_id)
            limpar_tela()

        elif opc == "5":
            limpar_tela()
            atualizar_atividade(id_usuario=user_id)
            limpar_tela()

        elif opc == "6":
            limpar_tela()
            nome = input("Digite o nome da categoria que deseja adicionar: ")
            inserir_categoria(nome)
            sleep(2)
            limpar_tela()

        elif opc == "8":
            limpar_tela()
            return

        else:
            limpar_tela()
